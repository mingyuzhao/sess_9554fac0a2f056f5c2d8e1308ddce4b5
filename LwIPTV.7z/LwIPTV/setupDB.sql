DROP DATABASE IF EXISTS iptv;
CREATE DATABASE iptv DEFAULT CHARACTER SET utf8;
USE iptv;

DROP TABLE IF EXISTS channel_tags;
DROP TABLE IF EXISTS channels;
DROP TABLE IF EXISTS tags;
DROP TABLE IF EXISTS members;

CREATE TABLE channels (
   id int(11) NOT NULL auto_increment,
   title varchar(50) NOT NULL,
   url varchar(1000) NOT NULL,
   logo varchar(1000),
   description varchar(500),
   PRIMARY KEY (id)
) DEFAULT CHARACTER SET utf8;

CREATE TABLE tags (
   id int(11) NOT NULL auto_increment,
   tag varchar(50) NOT NULL,
   PRIMARY KEY (id)
);

CREATE TABLE channel_tags (
   id int(11) NOT NULL auto_increment,
   tag_id int(11) NOT NULL,
   channel_id int(11) NOT NULL,
   PRIMARY KEY (id),
   FOREIGN KEY (tag_id) REFERENCES tags (id),
   FOREIGN KEY (channel_id) REFERENCES channels (id)
);

CREATE TABLE members (
   id int(11) NOT NULL auto_increment,
   user varchar(100) NOT NULL,
   pass VARCHAR(16),
   email varchar(100),
   PRIMARY KEY (id)
) DEFAULT CHARACTER SET utf8;

INSERT INTO `channels` (`title`, `url`, `logo`, `description`) VALUES
('广东体育频道', 'http://nclive.grtn.cn/typd/sd/live.m3u8', '', ''),
('广东国际频道', 'http://nclive.grtn.cn/gjpd/sd/live.m3u8', '', ''),
('广东少儿频道(TVS-5)', 'http://nclive.grtn.cn/tvs5/sd/live.m3u8', '', ''),
('广东嘉佳卡通', 'http://nclive.grtn.cn/jjkt/sd/live.m3u8', '', ''),
('广东高尔夫频道', 'http://nclive.grtn.cn/grfpd/sd/live.m3u8', '', ''),
('Silence HD TV', 'http://93.190.140.42:8081/SilenceTV/live/playlist.m3u8', 'https://divan.tv/img/global_img/channel_website/ua_1093.png', '美国舒缓频道a channel for a wide audience, it suits perfectly well for the entire family, since it has no age restrictions.'),
('MiaoMi-TV', 'http://d3kw4vhbdpgtqk.cloudfront.net/hls/miaomipcweb/prog_index.m3u8', 'http://www.miaomi-tv.com/us/assets/images/miao-mi-logo-color.png', 'Miao Mi(妙米频道)是专为3至6岁小朋友学习普通话而设的儿童自选频道'),
('凤凰卫视中文台', 'http://live.fengshows.com/live/PCC_500k/index.m3u8?ts=1534293541456&amp;amp;token=34bd3848748084b773f39a70db91e541', 'http://www.rologo.com/images/uploads/2012/01/PhonixTVlogo.png', '凤凰卫视旗下的主打新闻资讯、有时亦会播出MV频道'),
('MLB Network', 'http://mlblive-akc.mlb.com/ls01/mlbam/mlb_network/NETWORK_LINEAR_1/master_wired.m3u8', 'https://s3.amazonaws.com/schedulesdirect/assets/stationLogos/s62081_h3_aa.png', '美国职业棒球大联盟 - American television sports channel dedicated to baseball.'),
('河北卫视',  'http://weblive.hebtv.com/live/hbwsbq_bq/index.m3u8', 'https://upload.wikimedia.org/wikipedia/en/thumb/4/4d/HebeiTV.png/200px-HebeiTV.png', '河北广播电视台旗下的卫星频道，定位于以新闻节目为旗，人文节目为基，综艺节目强势出击。'),
('河北卫视1', 'http://weblive.hebtv.com/live/hbwsbq_lc/index.m3u8', 'https://upload.wikimedia.org/wikipedia/en/thumb/4/4d/HebeiTV.png/200px-HebeiTV.png', '河北广播电视台旗下的卫星频道，定位于以新闻节目为旗，人文节目为基，综艺节目强势出击。'),
('河北卫视2', 'http://weblive.hebtv.com/live/hbws_bq/index.m3u8', 'https://upload.wikimedia.org/wikipedia/en/thumb/4/4d/HebeiTV.png/200px-HebeiTV.png', '河北广播电视台旗下的卫星频道，定位于以新闻节目为旗，人文节目为基，综艺节目强势出击。'),
('河北卫视3', 'http://weblive.hebtv.com/live/hbws_lc/index.m3u8', 'https://upload.wikimedia.org/wikipedia/en/thumb/4/4d/HebeiTV.png/200px-HebeiTV.png', '河北广播电视台旗下的卫星频道，定位于以新闻节目为旗，人文节目为基，综艺节目强势出击。'),
('河北卫视4', 'http://weblive.hebtv.com/live/hbwsbq_bq/index.m3u8', 'https://upload.wikimedia.org/wikipedia/en/thumb/4/4d/HebeiTV.png/200px-HebeiTV.png', '河北广播电视台旗下的卫星频道，定位于以新闻节目为旗，人文节目为基，综艺节目强势出击。'),
('加拿大中文电视台', 'https://wowzaprodhd45-lh.akamaihd.net/i/96d54ef6_1@438617/master.m3u8', 'https://www.cntvcanada.com/sites/default/files/styles/scaled_max_width/public/media/images/cctv-logo-lg.png', '旨在以专业的新闻团队为加拿大及北美的华人提供最新、最快的新闻报道。'),
('台湾全美電視', 'https://dcunilive30-lh.akamaihd.net/i/dclive_1@535522/master.m3u8', 'http://www.aattv.com/wp-content/uploads/AAT-TV-Logo-Channel-2017-e1497895868387.png', '華盛頓州唯一的24小時亞裔電視台。本台電視節目以普通話/粵語和越南語提供新聞。'),
('阳光卫视', 'https://stream.chinasuntv.com/680k/mid_video_index.m3u8', 'http://www.zhengjicn.com/UploadFiles/zy_UploadFiles_7728/200705/20070527030423392.jpg', ''),
('VOA中文', 'https://voa-lh.akamaihd.net/i/voa_mpls_tvmc8@326847/index_0540_av-p.m3u8', 'https://pbs.twimg.com/media/DfB0ozWUcAA77Ws.jpg', ''),
('美国中文电视', 'http://media3.sinovision.net:1935/live/livestream/playlist.m3u8', 'https://pbs.twimg.com/profile_images/1184135310/SinoVision_LOGO.jpg', ''),
('8频道', 'https://d34e90s3s13i7n.cloudfront.net/hls/ch8ctv/master02.m3u8', 'https://pbs.twimg.com/profile_images/1184691455761059840/ivIIeZyR_400x400.jpg', '新加坡 普通话'),
('加拿大国家电视台', 'https://wowzaprodhd84-lh.akamaihd.net/i/4ae6355d_1@505999/index_2150400_av-p.m3u8', 'https://is5-ssl.mzstatic.com/image/thumb/Purple115/v4/76/c1/53/76c15327-5b26-bd9e-9d97-fd66eec67c0f/source/512x512bb.jpg', ''),
('NASA', 'http://hls.ums.ustream.tv/playlist/directhls/channel/6540154/playlist.m3u8?sgn=31d0dfb847c358d4cedcd2256dc4e1c42a7f13a7', 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b4/NASA_TV.svg/1200px-NASA_TV.svg.png', ''),
('MTV', 'http://unilivemtveu-lh.akamaihd.net/i/mtvno_1@346424/master.m3u8', 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0f/MTV_Logo_2010.svg/300px-MTV_Logo_2010.svg.png', 'US'),
('VOA 4 US', 'http://voa-lh.akamaihd.net/i/voa_mpls_tvmc3_3@320295/master.m3u8', 'https://d2v9ipibika81v.cloudfront.net/uploads/sites/210/voa-750.jpg', ''),
('广东房产频道', 'http://nclive.grtn.cn/fcpd/sd/live.m3u8', '', ''),
('南方购物频道', 'http://nclive.grtn.cn/nfgw/sd/live.m3u8', '', ''),
('广东科教', 'http://nclive.grtn.cn/tvs1hd/hd/live.m3u8', '', ''),
('广东汕头综合', 'http://dslive.grtn.cn/stzh/sd/live.m3u8', '', ''),
('广东佛山综合', 'http://dslive.grtn.cn/fszh/sd/live.m3u8', '', ''),
('广东江门综合', 'http://dslive.grtn.cn/jmzh/sd/live.m3u8', '', ''),
('广东阳江综合', 'http://dslive.grtn.cn/yjzh/sd/live.m3u8', '', ''),
('广东河源综合', 'http://dslive.grtn.cn/hyzh/sd/live.m3u8', '', ''),
('华数儿歌', 'http://hls-ott-zhibo.wasu.tv/live/234/index.m3u8', '', ''),
('华数美食HD', 'http://hls-ott-zhibo.wasu.tv/live/256/index.m3u8', '', ''),
('华数偶像HD', 'http://hls-ott-zhibo.wasu.tv/live/257/index.m3u8', '', ''),
('华数爱情FHD', 'http://hls-ott-zhibo.wasu.tv/live/261/index.m3u8', '', ''),
('华数古装剧', 'http://hls-ott-zhibo.wasu.tv/live/259/index.m3u8', '', ''),
('华数国外动作', 'http://hls-ott-zhibo.wasu.tv/live/305/index.m3u8', '', ''),
('华数时装1', 'http://hls-ott-zhibo.wasu.tv/live/297/index.m3u8', '', ''),
('华数时装2', 'http://hls-ott-zhibo.wasu.tv/live/299/index.m3u8', '', ''),
('华数时尚1', 'http://hls-ott-zhibo.wasu.tv/live/300/index.m3u8', '', ''),
('华数时尚2', 'http://hls-ott-zhibo.wasu.tv/live/304/index.m3u8', '', ''),
('华数有象视频', 'http://hls-ott-zhibo.wasu.tv/live/301/index.m3u8', '', ''),
('华数视频', 'http://hls-ott-zhibo.wasu.tv/live/302/index.m3u8', '', ''),
('点掌财经', 'http://bdlive.aniu.tv/live/anzb.m3u8', '', ''),
('点掌财经', 'http://cclive2.aniu.tv/live/anzb.m3u8', '', ''),
('广东综艺', 'http://nclive.grtn.cn/4K/sd/live.m3u8', '', ''),
('广东现代教育', 'http://nclive.grtn.cn/jypd/sd/live.m3u8', '', ''),
('广东新闻频道', 'http://nclive.grtn.cn/xwpd/sd/live.m3u8', '', ''),
('VOA 4 Africa', 'https://voa-lh.akamaihd.net/i/voa_mpls_tvmc6@320298/index_0540_av-p.m3u8', 'https://pbs.twimg.com/profile_images/1882406101/voa-button-africa3_400x400.jpg', ''),
('24/7 Retro TV (Opt-1)', 'http://247retrotv.com:1935/live/smil:247retro.smil/chunklist_w1193920237_b1928000_sleng.m3u8', 'http://www.247retro.com/images/sidebar_logo_gradient.jpg', 'Movies'),
('American Horrors (Opt-1)', 'http://170.178.189.66:1935/live/Stream1/.m3u8', 'https://image.roku.com/developer_channels/prod/16f5571a82819e8992a748c70b256cbe63105f4b546b73d129668dc2cb701d91.png', ''),
('California Music Channel (Opt-1)', 'https://cmctv.ios.internapcdn.net/cmctv_vitalstream_com/live_1/CMC-TV/master.m3u8?fluxustv.m3u8', 'https://i.imgur.com/9TbpsS0.png', ''),
('Titanic TV', 'https://a.jsrdn.com/broadcast/22719/+0000/hi/c.m3u8', 'https://i.imgur.com/t8ZCTXN.jpg', ''),
('加拿大Space', 'http://pe-ak-lp01a-9c9media.akamaized.net/live/Space/p/hls/00000201/689924a518f2c776/index/2176f3ac/live/stream/h264/v1/3500000/manifest.m3u8', 'http://bc.syscy.com/syscyi/i-article/20130307215104232886.jpg', ''),
('FTV News', 'http://6.mms.vlog.xuite.net/hls/ftvtv/index.m3u8?fluxustv.m3u8', 'https://piceltaott-elta.cdn.hinet.net/upload/channel/902.png', '台湾'),
('Hunt Channel', 'https://1111296894.rsc.cdn77.org/LS-ATL-56868-1/index.m3u8', 'http://bama-q.tv/wp-content/uploads/2017/10/HuntChannel-copy-uai-720x476.png', 'Sport, US'),
('靖天欢乐HD', 'http://61.58.60.230:9319/live/201.m3u8', '', ''),
('AYSAR MOVIE 4 (Opt-1)', 'http://js.hls.huya.com/huyalive/29106097-2689446042-11551082794746642432-2789253870-10057-A-0-1_1200.m3u8', '', ''),
('江苏卫视', 'http://live2.plus.hebtv.com/jsws/sd/live.m3u8', '', ''),
('广东卫视', 'http://nclive.grtn.cn/gdws/sd/live.m3u8', 'http://www.yurunad.com/Mobile/uploadfiles/pictures/product/20190715095022_9887.jpg_240X331.jpg', ''),
('南方卫视TVS2', 'http://nclive.grtn.cn/tvs2/sd/live.m3u8', 'http://www.tvyan.com/uploads/dianshi/tvs2.jpg', ''),
('安徽国际', 'http://zbbf2.ahtv.cn/live/subfile/submain.m3u8?__hlslivecid=live%2Fdab&_redcdnuserid=6714458678921446128', 'http://www.zuiaishiting.com/img/tv/ah12.jpg', ''),
('重庆卫视', 'https://onsitecdn.cbgcloud.com/76btqk/d6tb4v.m3u8', 'https://gss2.bdstatic.com/9fo3dSag_xI4khGkpoWK1HF6hhy/baike/w%3D268%3Bg%3D0/sign=f4782d1d26381f309e198aaf913a2b35/ca1349540923dd543c19b84ddf09b3de9c8248a8.jpg', ''),
('云南卫视', 'http://hwapi.yunshicloud.com/8xughf/e0bx15.m3u8', '', ''),
('Stadium', 'https://d28avce4cnwu2y.cloudfront.net/v1/manifest/61a556f78e4547c8ab5c6297ea291d6350767ca2/Mux/37f5dd6d-5713-4998-8354-8c6675612b42/1.m3u8', 'https://upload.wikimedia.org/wikipedia/en/b/b2/Stadium_TV_network_logo.png', ''),
('乌贼说故事', 'https://ws.streamhls.huya.com/huyalive/1444264308-1444264308-6203067969640071168-4655558802-10057-A-0-1_1200/playlist.m3u8', '', '电影解说'),
('越哥看电影', 'https://ws.streamhls.huya.com/huyalive/94525224-2700236716-11597428386678439936-2112795098-10057-A-0-1_1200/playlist.m3u8', '', '电影解说'),
('老香菇', 'https://ws.streamhls.huya.com/huyalive/94525224-2701809014-11604181355168006144-158309560-10057-A-0-1_1200/playlist.m3u8', '', '电影解说'),
('阿祥看电影', 'https://ws.streamhls.huya.com/huyalive/1199512004776-1199512004776-5223235107350904832-2399024133008-10057-A-0-1_1200/playlist.m3u8', '', '电影解说'),
('鬼话怪谈', 'https://ws.streamhls.huya.com/huyalive/1199511997436-1199511997436-5223203582290952192-2399024118328-10057-A-0-1_1200/playlist.m3u8', '', '电影解说'),
('权力的游戏', 'https://ws.streamhls.huya.com/huyalive/1199512340051-1199512340051-5224675102511071232-2399024803558-10057-A-0-1_1200/playlist.m3u8', '', ''),
('周星驰', 'https://tx.hls.huya.com/huyalive/94525224-2460685313-10568562945082523648-2789274524-10057-A-0-1_1200.m3u8', '', ''),
('李连杰', 'https://js.hls.huya.com/huyalive/94525224-2460686093-10568566295157014528-2789253848-10057-A-0-1_1200.m3u8', '', ''),
('宝莲灯前传', 'http://js.hls.huya.com/huyalive/30765679-2525901744-10848665383389364224-2847699200-10057-A-0-1_1200.m3u8', '', ''),
('赵本山小品系列', 'http://js.hls.huya.com/huyalive/29106097-2689443426-11551071559112196096-2789253866-10057-A-0-1_1200.m3u8', '', ''),
('虎牙漫威电影', 'http://tx.hls.huya.com/huyalive/30765679-2504742278-10757786168918540288-3049003128-10057-A-0-1.m3u8', '', ''),
('虎牙复仇犯罪', 'http://tx.hls.huya.com/huyalive/28466698-2689661530-11552008308659322880-3049003102-10057-A-0-1.m3u8', '', ''),
('虎牙影视女神港片', 'http://tx.hls.huya.com/huyalive/30765679-2484192476-10669525441389264896-2789274564-10057-A-0-1.m3u8', '', ''),
('虎牙影视真实改编', 'http://tx.hls.huya.com/huyalive/30765679-2554414680-10971127511022305280-3048991634-10057-A-0-1.m3u8', '', ''),
('虎牙影视惊悚电影', 'http://tx.hls.huya.com/huyalive/29106097-2689447600-11551089486305689600-2789274568-10057-A-1525420695-1.m3u8', '', ''),
('虎牙影视怪物科幻', 'http://tx.hls.huya.com/huyalive/30765679-2478268764-10644083292078342144-2847699106-10057-A-0-1.m3u8', '', ''),
('虎牙影视丧尸电影', 'http://tx.hls.huya.com/huyalive/29106097-2689286606-11550398022340837376-2789274544-10057-A-0-1.m3u8', '', ''),
('雍正王朝', 'https://txdirect.hls.huya.com/huyalive/29359996-2689277426-11550358594541060096-2847699098-10057-A-0-1_1200.m3u8', '', '');

INSERT INTO `tags` (`tag`) VALUES ('Sport'), ('News'), ('Movies');

INSERT INTO `channel_tags` (`tag_id`, `channel_id`)
   VALUES (1, 1),
          (1, 2);

INSERT INTO `members` (`user`, `pass`, `email`)
   VALUES ('Jerry1 Smith1', '1qaz2wsx', 'jerry1.smith1@gmail.com'),
          ('Jerry2 Smith2', '1qaz2wsx', 'jerry2.smith2@gmail.com'),
          ('wang', '1qaz2wsx', 'jerry3.smith3@gmail.com');
COMMIT;
